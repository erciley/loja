/* A chave publishable/anon do Supabase é pública por definição.
   A segurança dos dados precisa vir das políticas RLS no banco. */
const SUPABASE_URL = 'https://bvkcuhjkckyvffaffkpq.supabase.co';
const SUPABASE_KEY = 'sb_publishable_nuTP6MKsvVouhrWwEA4lVA_FPYA9CtB';
const supabaseClient = window.supabase
  ? window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY)
  : null;

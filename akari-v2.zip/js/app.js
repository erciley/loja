
// ═══════════════════════════════════════════════
// CONFIGURAÇÕES
// ═══════════════════════════════════════════════
const WA_NUMBER = '5592986471212';
const STORAGE_KEY = 'akari_products_v1';
const CREDIT_MONTHLY_RATE = 0;

// ═══════════════════════════════════════════════
// ESTADO
// ═══════════════════════════════════════════════
const RARITY_MAP = {
  'ultra rare':'b-ultra','ex':'b-ex','holográfico':'b-holo','holografico':'b-holo',
  'rara':'b-rare','pack':'b-pack','kit':'b-pack','full art':'b-ultra'
};

let PRODUCTS = [];
let cart = [];
let currentFilter = 'all';
let adminLoggedIn = false;
let editingId = null;
let adminSearchTerm = '';
let adminQuickFilter = 'all';
let catalogSearchTerm = '';
let paymentMethod = 'pix';
let creditInstallments = 2;
let fulfillmentMethod = 'self';

const CATEGORY_LABELS = {pokemon_tcg:'Pokémon TCG',one_piece:'One Piece',accessories:'Acessórios'};
const SUBCATEGORY_LABELS = {etb:'ETB',deck:'Deck',blister:'Blister',box:'Box',mini_box:'Mini Box',booster_box:'Booster Box'};

function normalizeSearchText(value){
  return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
}

function legacyCategory(p){
  const text = ((p.type || '') + ' ' + (p.name || '')).toLowerCase();
  if(text.includes('one piece')) return 'one_piece';
  if(text.includes('acess') || text.includes('sleeve') || text.includes('binder') || text.includes('pasta')) return 'accessories';
  return 'pokemon_tcg';
}

function legacySubcategory(p){
  const legacy = p.cat || p.product_type || '';
  const text = ((p.type || '') + ' ' + (p.name || '')).toLowerCase();
  if(text.includes('etb')) return 'etb';
  if(text.includes('booster box')) return 'booster_box';
  if(text.includes('mini box')) return 'mini_box';
  if(text.includes('quádruplo') || text.includes('quadruplo') || text.includes('triplo') || text.includes('blister')) return 'blister';
  if(text.includes('deck')) return 'deck';
  if(text.includes('box')) return 'box';
  if(legacy === 'card') return 'blister';
  if(legacy === 'pack') return 'booster_box';
  if(legacy === 'kit') return 'box';
  return '';
}

// ═══════════════════════════════════════════════
// PRODUTOS - Supabase
// O site le e grava na tabela "products". O localStorage fica so como backup/fallback.
function normalizeProduct(p){
  const rarity = (p.badge || p.rarity || 'Disponivel').trim();
  const featuredWeek = p.featured_week === true || p.featuredWeek === true || p.featured_week === 1 || p.featuredWeek === 1 || p.featured_week === 'true' || p.featuredWeek === 'true';
  const featuredOrderRaw = p.featured_order ?? p.featuredOrder;
  const regularPrice = Number(p.regular_price ?? p.regularPrice ?? p.price) || 0;
  const salePriceRaw = p.sale_price ?? p.salePrice;
  const salePrice = salePriceRaw === null || salePriceRaw === undefined || salePriceRaw === '' ? null : Number(salePriceRaw);
  const hasSalePrice = Number.isFinite(salePrice) && salePrice >= 0 && salePrice < regularPrice;
  const categoryMain = p.category_main || p.categoryMain || legacyCategory(p);
  const legacySub = p.subcategory || legacySubcategory(p);
  const subcategory = categoryMain === 'pokemon_tcg'
    ? (['single','triple','quadruple'].includes(legacySub) ? 'blister' : legacySub)
    : '';
  return {
    id: p.id,
    name: p.name || '',
    type: p.type || p.category || '',
    description: p.description || '',
    regular_price: regularPrice,
    sale_price: hasSalePrice ? salePrice : null,
    price: hasSalePrice ? salePrice : regularPrice,
    badge: rarity,
    badgeClass: p.badgeClass || p.badge_class || RARITY_MAP[rarity.toLowerCase()] || 'b-default',
    emoji: p.emoji || 'CARD',
    photo: p.photo || p.image_url || '',
    cat: p.cat || p.product_type || 'card',
    category_main: categoryMain,
    subcategory: subcategory,
    stock: p.stock === null || p.stock === undefined || p.stock === '' ? null : Number(p.stock),
    status: p.status || '',
    featured_week: featuredWeek,
    featured_order: featuredOrderRaw === null || featuredOrderRaw === undefined || featuredOrderRaw === '' ? null : Number(featuredOrderRaw),
  };
}

function productFromSupabase(row){
  return normalizeProduct(row);
}

function productToSupabase(product){
  return {
    id: product.id || undefined,
    name: product.name,
    type: product.type,
    category: product.type,
    description: product.description,
    price: product.price,
    regular_price: product.regular_price,
    sale_price: product.sale_price,
    badge: product.badge,
    badge_class: product.badgeClass,
    emoji: product.emoji,
    photo: product.photo,
    image_url: product.photo,
    cat: product.cat,
    product_type: product.cat,
    category_main: product.category_main,
    subcategory: product.subcategory || null,
    stock: product.stock,
    status: product.status,
    featured_week: Boolean(product.featured_week),
    featured_order: product.featured_order,
  };
}

function loadLocalProducts(){
  const raw = localStorage.getItem(STORAGE_KEY);
  if(raw){
    try{ PRODUCTS = JSON.parse(raw).map(normalizeProduct); }catch(e){ PRODUCTS = []; }
  } else {
    PRODUCTS = [
      {id:1,name:'Charizard EX',type:'Pokemon - Scarlet & Violet',price:89.90,badge:'EX',badgeClass:'b-ex',emoji:'CARD',photo:'',cat:'card',stock:2,status:''},
      {id:2,name:'Pikachu Holo',type:'Pokemon - Classic',price:45.00,badge:'Holografico',badgeClass:'b-holo',emoji:'CARD',photo:'',cat:'card',stock:5,status:''},
      {id:3,name:'Pack Booster SV',type:'Scarlet & Violet - 10 cartas',price:35.00,badge:'Pack',badgeClass:'b-pack',emoji:'PACK',photo:'',cat:'pack',stock:10,status:''},
    ];
    saveProductsToStorage();
  }
}

async function loadProducts(){
  const grid = document.getElementById('products-grid');
  if(grid) grid.innerHTML = '<p class="loading-msg">Carregando produtos...</p>';

  if(!supabaseClient){
    loadLocalProducts();
    renderProducts(currentFilter);
    return;
  }

  const { data, error } = await supabaseClient
    .from('products')
    .select('*')
    .order('id', { ascending: true });

if(error){
  console.error('Erro ao carregar produtos do Supabase:', error);

  PRODUCTS = [];
  renderProducts(currentFilter);

  showToast('Erro ao conectar ao Supabase. Verifique a tabela products.');
  return;
}

  PRODUCTS = (data || []).map(productFromSupabase);
  saveProductsToStorage();
  renderProducts(currentFilter);
  if(adminLoggedIn) renderAdminPanel();
}

function saveProductsToStorage(){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(PRODUCTS));
}

function nextId(){
  return PRODUCTS.length > 0 ? Math.max(...PRODUCTS.map(p=>Number(p.id)||0)) + 1 : 1;
}

// ═══════════════════════════════════════════════
// RENDER LOJA
// ═══════════════════════════════════════════════
function renderHeroHighlights(){
  const grid = document.getElementById('hero-highlight-grid');
  if(!grid) return;
  const highlights = PRODUCTS
    .filter(p => p.featured_week && p.status !== 'esgotado' && (p.stock === null || p.stock > 0 || p.status === 'pré-venda' || p.status === 'pre-venda'))
    .sort((a, b) => {
      const orderA = Number.isFinite(a.featured_order) ? a.featured_order : Number.MAX_SAFE_INTEGER;
      const orderB = Number.isFinite(b.featured_order) ? b.featured_order : Number.MAX_SAFE_INTEGER;
      return orderA - orderB || (Number(b.id) || 0) - (Number(a.id) || 0);
    })
    .slice(0, 3);

  if(highlights.length === 0){
    grid.innerHTML = '<div class="hero-highlight-empty">Nenhum produto foi marcado como Destaque da Semana.</div>';
    return;
  }

  grid.innerHTML = highlights.map(p => {
    const priceStr = p.price.toLocaleString('pt-BR', {minimumFractionDigits:2,maximumFractionDigits:2});
    const media = p.photo
      ? '<img src="' + p.photo + '" alt="' + p.name + '" loading="lazy" onerror="this.parentElement.textContent=\'CARD\'">'
      : '<span>' + (p.cat === 'pack' ? 'PACK' : 'CARD') + '</span>';
    return '<a class="hero-highlight-card" href="#produtos">' +
      '<div class="hero-highlight-media">' + media + '</div>' +
      '<div><div class="hero-highlight-name">' + p.name + '</div>' +
      '<div class="hero-highlight-meta">' + (p.badge || p.type || 'Produto') + '</div>' +
      '<div class="hero-highlight-price">R$ ' + priceStr + '</div></div>' +
    '</a>';
  }).join('');
}

function renderProducts(filter){
  renderHeroHighlights();
  const grid = document.getElementById('products-grid');
  const [category, subcategory] = filter.split(':');
  let filtered = filter === 'all' ? PRODUCTS : PRODUCTS.filter(p => p.category_main === category && (!subcategory || p.subcategory === subcategory));
  const search = normalizeSearchText(catalogSearchTerm);
  if(search){
    filtered = filtered.filter(p => normalizeSearchText([
      p.name,
      p.type,
      p.description,
      p.badge,
      CATEGORY_LABELS[p.category_main],
      SUBCATEGORY_LABELS[p.subcategory]
    ].join(' ')).includes(search));
  }
  const searchCount = document.getElementById('catalog-search-count');
  if(searchCount) searchCount.textContent = search ? `${filtered.length} ${filtered.length === 1 ? 'produto encontrado' : 'produtos encontrados'}` : '';
  if(PRODUCTS.length === 0){
    grid.innerHTML = '<p class="empty-msg">Nenhum produto cadastrado ainda. Use o painel Admin para adicionar!</p>';
    return;
  }
  if(filtered.length === 0){
    grid.innerHTML = `<p class="empty-msg">${search ? 'Nenhum produto corresponde à sua pesquisa.' : 'Nenhum produto nessa categoria no momento.'}</p>`;
    return;
  }
  grid.innerHTML = filtered.map(p => {
    const inCart = cart.find(c => c.id === p.id);
    const inCartQty = inCart ? inCart.qty : 0;
    const isPresale = p.status === 'pré-venda' || p.status === 'pre-venda';
    const outOfStock = p.status === 'esgotado' || (!isPresale && p.stock !== null && p.stock <= 0);
    const atMaxStock = !isPresale && p.stock !== null && inCartQty >= p.stock;
    let stockHTML = '';
    if(outOfStock) stockHTML = '<div class="stock-info stock-out">✕ Esgotado</div>';
    else if(isPresale) stockHTML = '<div class="stock-info stock-presale">◷ Pré-venda</div>';
    else if(p.stock !== null && p.stock <= 3) stockHTML = `<div class="stock-info stock-low">⚠ Só ${p.stock} ${p.stock===1?'unidade':'unidades'}!</div>`;
    const mediaHTML = p.photo ? `<img src="${p.photo}" alt="${p.name}" loading="lazy" onerror="this.style.display='none'">` : '';
    let btnLabel = '+ Carrinho';
    if(outOfStock) btnLabel = 'Esgotado';
    else if(isPresale) btnLabel = inCart ? '✓ Reservado' : '+ Reservar';
    else if(inCart) btnLabel = '✓ Adicionado';
    const priceStr = p.price.toLocaleString('pt-BR', {minimumFractionDigits:2,maximumFractionDigits:2});
    const regularPriceStr = p.regular_price.toLocaleString('pt-BR', {minimumFractionDigits:2,maximumFractionDigits:2});
    const priceHTML = p.sale_price
      ? `<span class="prod-price-old">R$ ${regularPriceStr}</span><span class="prod-price-label prod-price-card">preço normal</span><span class="prod-price">R$ ${priceStr}</span><span class="prod-price-label prod-price-pix">exclusivo no Pix</span>`
      : `<span class="prod-price">R$ ${priceStr}</span><span class="prod-price-label">Pix ou cartão à vista</span>`;
    return `<div class="product-card ${outOfStock?'sold-out':''}" id="pc-${p.id}">
      <div class="prod-img">
        <span class="prod-badge ${p.badgeClass}">${p.badge}</span>
        ${mediaHTML}
        <span class="prod-emoji-fallback">${p.emoji}</span>
      </div>
      <div class="prod-body">
        <div class="prod-name">${p.name}</div>
        <div class="prod-type">${CATEGORY_LABELS[p.category_main] || p.type}${p.subcategory ? ' · ' + (SUBCATEGORY_LABELS[p.subcategory] || p.subcategory) : ''}</div>
        ${p.description ? `<div class="prod-description">${p.description}</div>` : ''}
        ${stockHTML}
        <div class="prod-footer">
          <span class="prod-price-wrap">${priceHTML}</span>
          <button class="add-btn ${inCart?'added':''}" ${outOfStock||atMaxStock?'disabled':''} onclick="addToCart(${p.id})">${btnLabel}</button>
        </div>
      </div>
    </div>`;
  }).join('');
}

function setCatalogSearch(value){
  catalogSearchTerm = value;
  const clearButton = document.getElementById('catalog-search-clear');
  if(clearButton) clearButton.classList.toggle('show', value.length > 0);
  renderProducts(currentFilter);
}

function clearCatalogSearch(){
  catalogSearchTerm = '';
  const input = document.getElementById('catalog-search-input');
  const clearButton = document.getElementById('catalog-search-clear');
  if(input){ input.value = ''; input.focus(); }
  if(clearButton) clearButton.classList.remove('show');
  renderProducts(currentFilter);
}

function filterProducts(cat, el){
  currentFilter = cat;
  const isPokemon = cat === 'pokemon_tcg' || cat.startsWith('pokemon_tcg:');
  document.getElementById('pokemon-subfilters').classList.toggle('open', isPokemon);
  if(el.classList.contains('tab')) document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  if(el.classList.contains('subtab')) document.querySelectorAll('.subtab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  renderProducts(cat);
}

// ═══════════════════════════════════════════════
// CARRINHO
// ═══════════════════════════════════════════════
function addToCart(id){
  const prod = PRODUCTS.find(p => p.id === id);
  if(!prod) return;
  if(prod.status === 'esgotado'){ showToast('Produto esgotado!'); return; }
  const existing = cart.find(c => c.id === id);
  const currentQty = existing ? existing.qty : 0;
  if(prod.stock !== null && currentQty >= prod.stock){ showToast('Estoque máximo atingido!'); return; }
  if(existing) existing.qty++;
  else cart.push({...prod, qty:1});
  updateCartUI();
  renderProducts(currentFilter);
  showToast(prod.emoji + ' ' + prod.name + ' adicionado!');
}

function removeFromCart(id){
  cart = cart.filter(c => c.id !== id);
  updateCartUI();
  renderProducts(currentFilter);
}

function changeQty(id, delta){
  const item = cart.find(c => c.id === id);
  if(!item) return;
  const prod = PRODUCTS.find(p => p.id === id);
  if(delta > 0 && prod && prod.stock !== null && item.qty >= prod.stock){ showToast('Estoque máximo atingido!'); return; }
  item.qty += delta;
  if(item.qty <= 0) removeFromCart(id);
  else updateCartUI();
  renderProducts(currentFilter);
}

function formatMoney(value){
  return 'R$ ' + value.toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});
}

function getCartTotals(){
  const subtotal = cart.reduce((sum, item) => sum + Number(item.regular_price ?? item.price) * item.qty, 0);
  const pixTotal = cart.reduce((sum, item) => {
    const pixPrice = item.sale_price !== null && item.sale_price !== undefined ? Number(item.sale_price) : Number(item.regular_price ?? item.price);
    return sum + pixPrice * item.qty;
  }, 0);
  const pixDiscount = Math.max(0, subtotal - pixTotal);
  const interest = paymentMethod === 'credit' && creditInstallments > 1
    ? subtotal * (Math.pow(1 + CREDIT_MONTHLY_RATE, creditInstallments - 1) - 1)
    : 0;
  const total = paymentMethod === 'pix' ? pixTotal : subtotal + interest;
  return {subtotal, pixTotal, pixDiscount, interest, total, installmentValue: total / (paymentMethod === 'credit' ? creditInstallments : 1)};
}

function setPaymentMethod(method){
  paymentMethod = method;

  document.getElementById('payment-pix').classList.toggle('active', method === 'pix');
  document.getElementById('payment-credit').classList.toggle('active', method === 'credit');

  document.getElementById('installment-field').classList.toggle('open', method === 'credit');

  const condition = document.getElementById('payment-condition');
  condition.classList.toggle('credit', method === 'credit');

  condition.textContent = method === 'pix'
    ? 'O preço promocional e o desconto abaixo são exclusivos para pagamento via Pix.'
    : 'No cartão aceitamos pagamento em até 3x sem juros.';

  updateCartUI();
}

function setCreditInstallments(value){
  creditInstallments = Math.max(1, Math.min(12, parseInt(value, 10) || 1));
  updateCartUI();
}

function setFulfillmentMethod(method){
  fulfillmentMethod = method;
  document.getElementById('fulfillment-self').classList.toggle('active', method === 'self');
  document.getElementById('fulfillment-app').classList.toggle('active', method === 'app');
  document.getElementById('cart-fulfillment-label').textContent = method === 'self' ? 'Vou buscar' : 'Retirada por aplicativo';
  document.getElementById('fulfillment-info').innerHTML = method === 'self'
    ? `<strong>Obrigado por escolher retirar seu pedido na Akari Cards Store!</strong><p>Somos uma loja 100% online e não possuímos loja física.</p><p>Ao chegar, basta avisar que veio retirar um pedido da Akari Cards Store. Assim que formos avisados, iremos até você para realizar a entrega.</p>`
    : `<strong>Retirada por aplicativo (Uber, 99 etc.)</strong><p>Caso prefira, você também pode solicitar a retirada por aplicativo. Basta pedir a corrida para buscar o seu pedido.</p><p>A solicitação e o pagamento do motorista são feitos diretamente por você, permitindo acompanhar o trajeto em tempo real e entrar em contato com o motorista, se necessário.</p><p>Assim que o pedido for confirmado, enviaremos o endereço para que você possa solicitar a retirada.</p>`;
}

function updateCartUI(){
  const totals = getCartTotals();
  const count = cart.reduce((s,c) => s + c.qty, 0);
  const badge = document.getElementById('cart-count');
  badge.textContent = count;
  badge.classList.toggle('show', count > 0);
  document.getElementById('cart-subtotal').textContent = formatMoney(totals.subtotal);
  document.getElementById('cart-discount').textContent = '- ' + formatMoney(totals.pixDiscount);
  document.getElementById('cart-interest').textContent = '+ ' + formatMoney(totals.interest);
  document.getElementById('cart-discount-row').hidden = paymentMethod !== 'pix';
  document.getElementById('cart-interest-row').hidden = paymentMethod !== 'credit' || totals.interest <= 0;
  document.getElementById('cart-total-label').textContent = paymentMethod === 'pix' ? 'Total no Pix' : 'Total no cartão';
  document.getElementById('cart-total').textContent = formatMoney(totals.total);
  document.getElementById('installment-total').textContent = paymentMethod === 'credit'
    ? `${creditInstallments}x de ${formatMoney(totals.installmentValue)}${creditInstallments === 1 ? ' sem juros' : ' com juros'}`
    : (totals.pixDiscount > 0 ? `Você economiza ${formatMoney(totals.pixDiscount)} pagando no Pix.` : 'Pagamento à vista via Pix.');
  document.getElementById('wa-finalize').disabled = cart.length === 0;
  const container = document.getElementById('cart-items');
  if(cart.length === 0){
    container.innerHTML = '<div class="cart-empty"><span class="cart-empty-icon">🃏</span>Seu carrinho está vazio.<br>Adicione cards para continuar!</div>';
    return;
  }
  container.innerHTML = cart.map(item => {
    const unitPrice = paymentMethod === 'pix' && item.sale_price !== null && item.sale_price !== undefined
      ? Number(item.sale_price)
      : Number(item.regular_price ?? item.price);
    const priceStr = (unitPrice * item.qty).toLocaleString('pt-BR',{minimumFractionDigits:2});
    const media = item.photo ? `<img src="${item.photo}" alt="${item.name}">` : item.emoji;
    const stockLabel = item.stock === null ? 'Estoque disponível' : `${item.stock} em estoque`;
    return `<div class="cart-item">
      <span class="ci-media">${media}</span>
      <div class="ci-info">
        <div class="ci-name">${item.name}</div>
        <div class="ci-type">${CATEGORY_LABELS[item.category_main] || item.type}</div>
        <div class="ci-stock">${stockLabel}</div>
        <div class="ci-qty">
          <button class="qty-btn" onclick="changeQty(${item.id},-1)">−</button>
          <span class="qty-num">${item.qty}</span>
          <button class="qty-btn" onclick="changeQty(${item.id},1)">+</button>
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:.3rem">
        <span class="ci-price">R$ ${priceStr}</span>
        <button class="ci-del" onclick="removeFromCart(${item.id})">✕</button>
      </div>
    </div>`;
  }).join('');
}

function toggleCart(){
  document.getElementById('cart-panel').classList.toggle('open');
  document.getElementById('overlay').classList.toggle('open');
}

function showToast(msg){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2200);
}

function finalizeWA(){
  if(cart.length === 0) return;
  const totals = getCartTotals();
  const lista = cart.map(item => {
    const unitPrice = paymentMethod === 'pix' && item.sale_price !== null && item.sale_price !== undefined
      ? Number(item.sale_price)
      : Number(item.regular_price ?? item.price);
    return '  • ' + item.name + ' x' + item.qty + ' = ' + formatMoney(unitPrice * item.qty);
  }).join('\n');
  const paymentDetails = paymentMethod === 'pix'
    ? `*Pagamento:* Pix\n*Subtotal normal:* ${formatMoney(totals.subtotal)}\n*Desconto no Pix:* - ${formatMoney(totals.pixDiscount)}\n*Total no Pix:* ${formatMoney(totals.total)}`
    : `*Pagamento:* Cartão em ${creditInstallments}x\n*Subtotal:* ${formatMoney(totals.subtotal)}\n*Juros:* + ${formatMoney(totals.interest)}\n*Parcelas:* ${creditInstallments}x de ${formatMoney(totals.installmentValue)}\n*Total no cartão:* ${formatMoney(totals.total)}`;
  const pickupDetails = fulfillmentMethod === 'self'
    ? '*Retirada:* Vou buscar'
    : '*Retirada:* Mandar buscar por aplicativo (Uber, 99 etc.)';
  const msg = 'Olá, Akari Cards Store! 🃏✨\n\nGostaria de fazer um pedido:\n\n' + lista + '\n\n' + paymentDetails + '\n' + pickupDetails + '\n\nAguardo a confirmação do pedido e o endereço para retirada.';
  window.open('https://wa.me/' + WA_NUMBER + '?text=' + encodeURIComponent(msg), '_blank');
}

function sendContactWA(){
  const nome = document.getElementById('c-nome').value.trim();
  const tel = document.getElementById('c-tel').value.trim();
  const msg = document.getElementById('c-msg').value.trim();
  if(!nome){alert('Por favor, informe seu nome.');return}
  const texto = 'Olá, Akari Cards Store! ✨\n\n*Nome:* ' + nome + '\n*WhatsApp:* ' + (tel||'não informado') + '\n\n*Mensagem:*\n' + (msg||'Olá, gostaria de mais informações!');
  window.open('https://wa.me/' + WA_NUMBER + '?text=' + encodeURIComponent(texto), '_blank');
}

// ═══════════════════════════════════════════════
// ADMIN — LOGIN
// ═══════════════════════════════════════════════
function openAdmin(){
  document.getElementById('admin-overlay').classList.add('open');
  if(adminLoggedIn) renderAdminPanel();
  else renderAdminLogin();
}

function closeAdmin(){
  document.getElementById('admin-overlay').classList.remove('open');
}

function renderAdminLogin(){
  document.getElementById('admin-body').innerHTML = `
    <div class="admin-login">
      <h3>🔐 ACESSO ADMIN</h3>
            <p>Entre com a conta de administrador cadastrada no Supabase</p>
      <div>
        <label class="pf-label" for="admin-email">E-mail</label>
        <input class="pf-input" type="email" id="admin-email" autocomplete="username" required onkeydown="if(event.key==='Enter')checkAdminLogin()">
      </div>
      <div>
        <label class="pf-label" for="admin-pw">Senha</label>
        <input class="pf-input" type="password" id="admin-pw" autocomplete="current-password" required onkeydown="if(event.key==='Enter')checkAdminLogin()">
      </div>
      <div class="admin-err" id="admin-err" role="alert">Não foi possível entrar. Confira suas credenciais.</div>
      <button class="btn-save" onclick="checkAdminLogin()" style="width:100%">Entrar</button>
    </div>`;
  setTimeout(() => { const el = document.getElementById('admin-pw'); if(el) el.focus(); }, 100);
}

async function checkAdminLogin(){
  if(!supabaseClient){
    const error = document.getElementById('admin-err');
    error.textContent = 'Supabase não configurado. O painel permanece bloqueado.';
    error.style.display = 'block';
    return;
  }
  const email = document.getElementById('admin-email').value.trim();
  const password = document.getElementById('admin-pw').value;
  const error = document.getElementById('admin-err');
  error.style.display = 'none';
  const { data, error: authError } = await supabaseClient.auth.signInWithPassword({ email, password });
  if(authError || !data.user || data.user.app_metadata?.role !== 'admin'){
    if(data.user) await supabaseClient.auth.signOut();
    error.textContent = authError ? 'Não foi possível entrar. Confira suas credenciais.' : 'Esta conta não tem acesso administrativo.';
    error.style.display = 'block';
    return;
  }
  adminLoggedIn = true;
  renderAdminPanel();
}

// ═══════════════════════════════════════════════
// ADMIN — PAINEL
// ═══════════════════════════════════════════════
function renderAdminPanel(){
  const featuredProducts = PRODUCTS
    .filter(p => p.featured_week)
    .sort((a, b) => {
      const orderA = Number.isFinite(a.featured_order) ? a.featured_order : Number.MAX_SAFE_INTEGER;
      const orderB = Number.isFinite(b.featured_order) ? b.featured_order : Number.MAX_SAFE_INTEGER;
      return orderA - orderB || (Number(b.id) || 0) - (Number(a.id) || 0);
    });
  const lowStock = PRODUCTS.filter(p => p.stock !== null && p.stock > 0 && p.stock <= 3).length;
  const outStock = PRODUCTS.filter(p => p.status === 'esgotado' || (p.stock !== null && p.stock <= 0)).length;
  const search = adminSearchTerm.toLowerCase();
  const shownProducts = PRODUCTS.filter(p => {
    const matchesSearch = !search || (p.name + ' ' + p.type + ' ' + (CATEGORY_LABELS[p.category_main] || '')).toLowerCase().includes(search);
    const matchesQuick = adminQuickFilter === 'all' ||
      (adminQuickFilter === 'featured' && p.featured_week) ||
      (adminQuickFilter === 'low' && p.stock !== null && p.stock > 0 && p.stock <= 3) ||
      (adminQuickFilter === 'out' && (p.status === 'esgotado' || (p.stock !== null && p.stock <= 0)));
    return matchesSearch && matchesQuick;
  });
  const rows = shownProducts.map(p => {
    const priceStr = p.price.toLocaleString('pt-BR',{minimumFractionDigits:2});
    const thumbHtml = p.photo
      ? `<div class="apr-thumb"><img src="${p.photo}" alt="" onerror="this.parentElement.innerHTML='${p.emoji}'"></div>`
      : `<div class="apr-thumb">${p.emoji}</div>`;
    const stockLabel = p.stock === null ? 'Ilimitado' : p.stock + ' un.';
    const statusLabel = p.status ? ' · ' + p.status : '';
    const stockClass = p.status === 'esgotado' || (p.stock !== null && p.stock <= 0) ? 'out' : (p.stock !== null && p.stock <= 3 ? 'low' : '');
    const featuredLabel = p.featured_week
      ? `<div class="featured-status">Destaque${p.featured_order ? ' #' + p.featured_order : ''}</div>`
      : '';
    return `<div class="admin-prod-row ${p.featured_week ? 'is-featured' : ''}">
      ${thumbHtml}
      <div class="apr-info">
        <div class="apr-name">${p.name}</div>
        <div class="apr-meta">${CATEGORY_LABELS[p.category_main] || 'Sem categoria'}${p.subcategory ? ' · ' + (SUBCATEGORY_LABELS[p.subcategory] || p.subcategory) : ''}${statusLabel}</div>
        <div class="stock-pill ${stockClass}">${stockLabel}</div>
        ${featuredLabel}
      </div>
      <div class="apr-price">R$ ${priceStr}</div>
      <div class="apr-actions">
        <button class="btn-edit" onclick="openProductForm(${p.id})">✎ Editar</button>
        <button class="btn-del" onclick="deleteProduct(${p.id})">× Excluir</button>
      </div>
    </div>`;
  }).join('') || '<div class="admin-empty">Nenhum produto ainda. Clique em "+ Novo Produto" para começar.</div>';

  document.getElementById('admin-body').innerHTML = `
    <div class="admin-dashboard">
      <div class="admin-stat"><div class="admin-stat-label">Produtos</div><div class="admin-stat-value">${PRODUCTS.length}</div></div>
      <div class="admin-stat"><div class="admin-stat-label">Destaques</div><div class="admin-stat-value gold">${featuredProducts.length}</div></div>
      <div class="admin-stat"><div class="admin-stat-label">Estoque baixo</div><div class="admin-stat-value">${lowStock}</div></div>
      <div class="admin-stat"><div class="admin-stat-label">Esgotados</div><div class="admin-stat-value">${outStock}</div></div>
    </div>
    <div class="admin-toolbar">
      <button class="btn-admin btn-add" onclick="openProductForm(null)">+ Novo Produto</button>
      <button class="btn-admin btn-export" onclick="exportBackup()">↓ Exportar</button>
      <button class="btn-admin btn-import" onclick="document.getElementById('import-file').click()">↑ Importar</button>
      <button class="btn-admin btn-logout" onclick="adminLogout()">Sair</button>
    </div>
    <div class="admin-controls">
      <input class="pf-input admin-search" id="admin-search" value="${adminSearchTerm}" placeholder="Buscar por nome, tipo ou categoria" oninput="filterAdminProducts(this.value)">
      <select class="pf-input admin-quick-filter" onchange="setAdminQuickFilter(this.value)">
        <option value="all" ${adminQuickFilter === 'all' ? 'selected' : ''}>Todos os produtos</option>
        <option value="featured" ${adminQuickFilter === 'featured' ? 'selected' : ''}>Destaques</option>
        <option value="low" ${adminQuickFilter === 'low' ? 'selected' : ''}>Estoque baixo</option>
        <option value="out" ${adminQuickFilter === 'out' ? 'selected' : ''}>Esgotados</option>
      </select>
    </div>
    <div class="admin-featured-summary">
      <div>
        <strong>Destaques da Semana: ${featuredProducts.length}</strong>
        <span>${featuredProducts.length > 3 ? 'Apenas os 3 primeiros pela ordem serão exibidos.' : 'Até 3 produtos podem aparecer na vitrine.'}</span>
      </div>
      <span>${featuredProducts.slice(0, 3).map(p => (p.featured_order || '-') + '. ' + p.name).join(' / ') || 'Nenhum selecionado'}</span>
    </div>
    <div class="admin-prod-list">${rows}</div>`;
}

function filterAdminProducts(value){
  adminSearchTerm = value;
  renderAdminPanel();
  const input = document.getElementById('admin-search');
  if(input){ input.focus(); input.setSelectionRange(input.value.length, input.value.length); }
}

function setAdminQuickFilter(value){
  adminQuickFilter = value;
  renderAdminPanel();
}

async function adminLogout(){
  adminLoggedIn = false;
  if(supabaseClient) await supabaseClient.auth.signOut();
  closeAdmin();
}

async function deleteProduct(id){
  if(!confirm('Excluir este produto?')) return;

  if(supabaseClient){
    const { error } = await supabaseClient.from('products').delete().eq('id', id);
    if(error){
      console.error('Erro ao excluir no Supabase:', error);
      alert('Nao foi possivel excluir no Supabase. Confira as politicas RLS da tabela products.');
      return;
    }
  }

  PRODUCTS = PRODUCTS.filter(p => p.id !== id);
  cart = cart.filter(p => p.id !== id);
  saveProductsToStorage();
  renderAdminPanel();
  renderProducts(currentFilter);
  updateCartUI();
  showToast('Produto excluido.');
}

// ═══════════════════════════════════════════════
// ADMIN — FORMULÁRIO DE PRODUTO
// ═══════════════════════════════════════════════
function openProductForm(id){
  editingId = id;
  const overlay = document.getElementById('prod-form-overlay');
  overlay.classList.add('open');
  document.getElementById('form-title').textContent = id ? 'Editar Produto' : 'Novo Produto';

  // reset
  document.getElementById('pf-id').value = '';
  document.getElementById('pf-name').value = '';
  document.getElementById('pf-type').value = '';
  document.getElementById('pf-description').value = '';
  document.getElementById('pf-price').value = '';
  document.getElementById('pf-sale-price').value = '';
  document.getElementById('pf-rarity').value = '';
  document.getElementById('pf-category-main').value = 'pokemon_tcg';
  document.getElementById('pf-subcategory').value = '';
  toggleSubcategoryField();
  document.getElementById('pf-stock').value = '';
  document.getElementById('pf-status').value = '';
  document.getElementById('pf-emoji').value = '🃏';
  document.getElementById('pf-photo-url').value = '';
  document.getElementById('pf-photo-file').value = '';
  document.getElementById('pf-featured-week').checked = false;
  document.getElementById('pf-featured-order').value = '';
  toggleFeaturedOrderField();
  document.getElementById('img-preview-wrap').innerHTML = '<span class="no-img">🃏</span>';

  if(id){
    const p = PRODUCTS.find(x => x.id === id);
    if(p){
      document.getElementById('pf-id').value = p.id;
      document.getElementById('pf-name').value = p.name;
      document.getElementById('pf-type').value = p.type;
      document.getElementById('pf-description').value = p.description || '';
      document.getElementById('pf-price').value = p.regular_price;
      document.getElementById('pf-sale-price').value = p.sale_price || '';
      document.getElementById('pf-rarity').value = p.badge;
      document.getElementById('pf-category-main').value = p.category_main || 'pokemon_tcg';
      document.getElementById('pf-subcategory').value = p.subcategory || '';
      toggleSubcategoryField();
      document.getElementById('pf-stock').value = p.stock === null ? '' : p.stock;
      document.getElementById('pf-status').value = p.status || '';
      document.getElementById('pf-emoji').value = p.emoji;
      document.getElementById('pf-photo-url').value = p.photo || '';
      document.getElementById('pf-featured-week').checked = Boolean(p.featured_week);
      document.getElementById('pf-featured-order').value = p.featured_order || '';
      toggleFeaturedOrderField();
      if(p.photo) document.getElementById('img-preview-wrap').innerHTML = `<img src="${p.photo}" alt="" onerror="this.parentElement.innerHTML='<span class=no-img>🃏</span>'">`;
    }
  }

  // listen for file upload
  document.getElementById('pf-photo-file').onchange = function(e){
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = async function(ev){
      // resize to max 800px wide via canvas
      const img = new Image();
      img.onload = function(){
        const MAX = 800;
        let w = img.width, h = img.height;
        if(w > MAX){ h = Math.round(h * MAX / w); w = MAX; }
        const canvas = document.createElement('canvas');
        canvas.width = w; canvas.height = h;
        canvas.getContext('2d').drawImage(img, 0, 0, w, h);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.82);
        document.getElementById('pf-photo-url').value = dataUrl;
        document.getElementById('img-preview-wrap').innerHTML = `<img src="${dataUrl}" alt="">`;
      };
      img.src = ev.target.result;
    };
    reader.readAsDataURL(file);
  };

  // listen for URL changes
  document.getElementById('pf-photo-url').oninput = function(){
    const url = this.value.trim();
    if(url) document.getElementById('img-preview-wrap').innerHTML = `<img src="${url}" alt="" onerror="this.parentElement.innerHTML='<span class=no-img>🃏</span>'">`;
    else document.getElementById('img-preview-wrap').innerHTML = '<span class="no-img">🃏</span>';
  };
}

function toggleSubcategoryField(){
  const isPokemon = document.getElementById('pf-category-main').value === 'pokemon_tcg';
  const wrap = document.getElementById('pf-subcategory-wrap');
  const input = document.getElementById('pf-subcategory');
  wrap.hidden = !isPokemon;
  input.disabled = !isPokemon;
  if(!isPokemon) input.value = '';
}

function toggleFeaturedOrderField(){
  const checked = document.getElementById('pf-featured-week').checked;
  const field = document.getElementById('pf-order-field');
  const input = document.getElementById('pf-featured-order');
  field.hidden = !checked;
  input.disabled = !checked;
  if(!checked) input.value = '';
}

function closeProductForm(){
  document.getElementById('prod-form-overlay').classList.remove('open');
}

async function saveProduct(){
  const name = document.getElementById('pf-name').value.trim();
  const regularPrice = parseFloat(document.getElementById('pf-price').value);
  const salePriceRaw = document.getElementById('pf-sale-price').value.trim();
  const salePrice = salePriceRaw === '' ? null : parseFloat(salePriceRaw);
  if(!name){ alert('Informe o nome do produto.'); return; }
  if(isNaN(regularPrice) || regularPrice < 0){ alert('Informe um preço normal válido.'); return; }
  if(salePrice !== null && (isNaN(salePrice) || salePrice < 0 || salePrice >= regularPrice)){ alert('O preço promocional deve ser menor que o preço normal.'); return; }

  const rarityRaw = document.getElementById('pf-rarity').value.trim();
  const stockRaw = document.getElementById('pf-stock').value.trim();
  const featuredWeek = document.getElementById('pf-featured-week').checked;
  const featuredOrderRaw = document.getElementById('pf-featured-order').value.trim();
  const featuredOrder = featuredOrderRaw === '' ? null : parseInt(featuredOrderRaw, 10);
  const categoryMain = document.getElementById('pf-category-main').value;
  const subcategory = categoryMain === 'pokemon_tcg' ? document.getElementById('pf-subcategory').value : '';
  if(featuredWeek && (featuredOrder === null || !Number.isInteger(featuredOrder) || featuredOrder < 1)){
    alert('Informe uma ordem de destaque válida (1, 2, 3...).');
    return;
  }

  let product = {
    id: editingId || undefined,
    name: name,
    type: document.getElementById('pf-type').value.trim(),
    description: document.getElementById('pf-description').value.trim(),
    regular_price: regularPrice,
    sale_price: salePrice,
    price: salePrice !== null ? salePrice : regularPrice,
    badge: rarityRaw || 'Disponivel',
    badgeClass: RARITY_MAP[rarityRaw.toLowerCase()] || 'b-default',
    emoji: document.getElementById('pf-emoji').value.trim() || 'CARD',
    photo: document.getElementById('pf-photo-url').value.trim(),
    cat: subcategory === 'blister' ? 'card' : (subcategory === 'booster_box' ? 'pack' : 'kit'),
    category_main: categoryMain,
    subcategory: subcategory,
    stock: stockRaw === '' ? null : parseInt(stockRaw, 10),
    status: document.getElementById('pf-status').value,
    featured_week: featuredWeek,
    featured_order: featuredWeek ? featuredOrder : null,
  };

  if(supabaseClient){
    const payload = productToSupabase(product);
    if(!editingId) delete payload.id;

    const { data, error } = await supabaseClient
      .from('products')
      .upsert(payload, { onConflict: 'id' })
      .select()
      .single();

    if(error){
      console.error('Erro ao salvar no Supabase:', error);
      alert('Nao foi possivel salvar no Supabase. Confira as colunas e as politicas RLS da tabela products.');
      return;
    }

    product = productFromSupabase(data);
  } else {
    product.id = editingId || nextId();
  }

  if(editingId){
    const idx = PRODUCTS.findIndex(p => p.id === editingId);
    if(idx !== -1) PRODUCTS[idx] = product;
  } else {
    PRODUCTS.push(product);
  }

  saveProductsToStorage();
  closeProductForm();
  renderAdminPanel();
  renderProducts(currentFilter);
  showToast(editingId ? 'Produto atualizado!' : 'Produto adicionado!');
}

// ═══════════════════════════════════════════════
// BACKUP
// ═══════════════════════════════════════════════
function exportBackup(){
  const data = JSON.stringify(PRODUCTS, null, 2);
  const blob = new Blob([data], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'akari-produtos-backup-' + new Date().toISOString().slice(0,10) + '.json';
  a.click();
  URL.revokeObjectURL(url);
  showToast('✓ Backup exportado!');
}

function importBackup(e){
  const file = e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = async function(ev){
    try{
      const data = JSON.parse(ev.target.result);
      if(!Array.isArray(data)) throw new Error('Formato invalido');
      if(!confirm('Importar ' + data.length + ' produtos? Isso substituira os dados atuais.')) return;

      const normalized = data.map(normalizeProduct);
      if(supabaseClient){
        const payload = normalized.map(productToSupabase);
        const { error } = await supabaseClient.from('products').upsert(payload, { onConflict: 'id' });
        if(error) throw error;
        await loadProducts();
      } else {
        PRODUCTS = normalized;
        saveProductsToStorage();
        renderAdminPanel();
        renderProducts(currentFilter);
      }

      showToast(data.length + ' produtos importados!');
    }catch(err){
      console.error('Erro ao importar backup:', err);
      alert('Arquivo invalido ou erro ao enviar para o Supabase.');
    }
  };
  reader.readAsText(file);
  e.target.value = '';
}

// ═══════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════
(async function initializeApp(){
  if(supabaseClient){
    const { data, error } = await supabaseClient.auth.getSession();
    const user = !error ? data.session?.user : null;
    adminLoggedIn = user?.app_metadata?.role === 'admin';
    if(user && !adminLoggedIn) await supabaseClient.auth.signOut();
  }
  await loadProducts();
})();

